<div class="w-full flex justify-center relative rounded-xl overflow-hidden bg-gray-600">
    <img src="{{ Storage::url($getRecord()->photo_path) }}" class=" h-40 w-full opacity-70 object-cover" alt="">
</div>
