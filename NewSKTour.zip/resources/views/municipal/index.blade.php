@section('title', 'USER REQUESTS')
<x-municipal-layout>
    <div class="bg-white relative p-6 rounded-xl bg-opacity-70">
        <livewire:user-request-list />
    </div>
</x-municipal-layout>
