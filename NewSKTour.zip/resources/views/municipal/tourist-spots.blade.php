@section('title', 'TOURIST SPOTS')
<x-municipal-layout>
    <div class="bg-white relative p-6 rounded-xl bg-opacity-70">
        <livewire:municipal.tourist-spot-list />
    </div>
</x-municipal-layout>
