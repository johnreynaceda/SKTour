@section('title', 'Tourist Spots')
<x-provincial-layout>
    <div class="bg-white relative p-6 rounded-xl bg-opacity-70">
        <livewire:municipal.tourist-spot-list />
    </div>
</x-provincial-layout>
