<x-tourist-layout>
    <div>
        <header class="uppercase font-bold text-2xl text-gray-700">Appointments</header>
        <div class="mt-10">
            <livewire:tourist.tourist-appointment />
        </div>
    </div>
</x-tourist-layout>
