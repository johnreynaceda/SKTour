<x-tourist-layout>
    <div>
        <livewire:layout.tourist-layout />
    </div>
</x-tourist-layout>
