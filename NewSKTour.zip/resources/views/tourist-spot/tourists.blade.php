@section('title', 'TOURISTS')
<x-tourist-spot-layout>
    <div class="bg-white relative rounded-xl p-10 bg-opacity-90">
        <livewire:tourist-spot.tourist-list />
    </div>
</x-tourist-spot-layout>
