@section('title', 'SPOT INFORMATION')
<x-tourist-spot-layout>
    <div>
        <livewire:tourist-spot.spot-list />
    </div>
</x-tourist-spot-layout>
