@section('title', 'SETTINGS')
<x-tourist-spot-layout>
    <div class="bg-white relative rounded-xl p-10 bg-opacity-90">
        <livewire:tourist-spot.spot-setting />
    </div>
</x-tourist-spot-layout>
