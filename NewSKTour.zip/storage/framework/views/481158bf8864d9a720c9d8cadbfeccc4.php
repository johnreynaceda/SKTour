<?php $__env->startSection('title', 'TOURISTS'); ?>
<?php if (isset($component)) { $__componentOriginal9280d2ef21ad3d913e3061dbc207dd0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9280d2ef21ad3d913e3061dbc207dd0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tourist-spot-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tourist-spot-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white relative rounded-xl p-10 bg-opacity-90">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tourist-spot.tourist-list', []);

$__html = app('livewire')->mount($__name, $__params, 'AtJT2f4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9280d2ef21ad3d913e3061dbc207dd0f)): ?>
<?php $attributes = $__attributesOriginal9280d2ef21ad3d913e3061dbc207dd0f; ?>
<?php unset($__attributesOriginal9280d2ef21ad3d913e3061dbc207dd0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9280d2ef21ad3d913e3061dbc207dd0f)): ?>
<?php $component = $__componentOriginal9280d2ef21ad3d913e3061dbc207dd0f; ?>
<?php unset($__componentOriginal9280d2ef21ad3d913e3061dbc207dd0f); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/tourist-spot/tourists.blade.php ENDPATH**/ ?>