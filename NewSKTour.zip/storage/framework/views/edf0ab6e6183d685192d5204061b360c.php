<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/livewire/municipal/tourist-spot-list.blade.php ENDPATH**/ ?>