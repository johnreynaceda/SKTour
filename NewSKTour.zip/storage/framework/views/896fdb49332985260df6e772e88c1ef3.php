<div class="w-full flex justify-center relative rounded-xl overflow-hidden bg-gray-600">
    <img src="<?php echo e(Storage::url($getRecord()->background_path)); ?>" class=" h-40 w-full opacity-70 object-cover"
        alt="">
    <!--[if BLOCK]><![endif]--><?php if(auth()->user()->user_type == 'provincial'): ?>
        <span
            class="text-white absolute uppercase left-4 font-bold bottom-1"><?php echo e($getRecord()->municipality->name); ?></span>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/filaments/tables/photo-bg.blade.php ENDPATH**/ ?>