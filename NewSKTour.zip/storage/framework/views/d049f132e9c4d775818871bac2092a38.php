<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name']); ?>
<?php foreach (array_filter((['name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal359675cf1ef67218375e82d01905bae0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal359675cf1ef67218375e82d01905bae0 = $attributes; } ?>
<?php $component = WireUi\View\Components\Error::resolve(['name' => $name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Error::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal359675cf1ef67218375e82d01905bae0)): ?>
<?php $attributes = $__attributesOriginal359675cf1ef67218375e82d01905bae0; ?>
<?php unset($__attributesOriginal359675cf1ef67218375e82d01905bae0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal359675cf1ef67218375e82d01905bae0)): ?>
<?php $component = $__componentOriginal359675cf1ef67218375e82d01905bae0; ?>
<?php unset($__componentOriginal359675cf1ef67218375e82d01905bae0); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\storage\framework\views/92c78fea67c55601542382748d67036d.blade.php ENDPATH**/ ?>