<?php $__env->startSection('title', 'Reports'); ?>
<?php if (isset($component)) { $__componentOriginalf6ce200a180bac3eb29b308c52601a20 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6ce200a180bac3eb29b308c52601a20 = $attributes; } ?>
<?php $component = App\View\Components\ProvincialLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('provincial-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProvincialLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white relative p-6 rounded-xl bg-opacity-70">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('provincial.provincial-report', []);

$__html = app('livewire')->mount($__name, $__params, 'd47dPeU', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <script>
            function printOut(data) {
                var mywindow = window.open('', '', 'height=1000,width=1000');
                mywindow.document.head.innerHTML =
                    '<title></title><link rel="stylesheet" href="<?php echo e(Vite::asset('resources/css/app.css')); ?>" />';
                mywindow.document.body.innerHTML = '<div>' + data +
                    '</div><script src="<?php echo e(Vite::asset('resources/js/app.js')); ?>"/>';

                mywindow.document.close();
                mywindow.focus(); // necessary for IE >= 10
                setTimeout(() => {
                    mywindow.print();
                    return true;
                }, 1000);
            }
        </script>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6ce200a180bac3eb29b308c52601a20)): ?>
<?php $attributes = $__attributesOriginalf6ce200a180bac3eb29b308c52601a20; ?>
<?php unset($__attributesOriginalf6ce200a180bac3eb29b308c52601a20); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6ce200a180bac3eb29b308c52601a20)): ?>
<?php $component = $__componentOriginalf6ce200a180bac3eb29b308c52601a20; ?>
<?php unset($__componentOriginalf6ce200a180bac3eb29b308c52601a20); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/provincial/reports.blade.php ENDPATH**/ ?>