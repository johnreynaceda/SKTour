<?php $__env->startSection('title', 'USER REQUESTS'); ?>
<?php if (isset($component)) { $__componentOriginal07f0778097f2e2be2b5b2161a0d3f3a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07f0778097f2e2be2b5b2161a0d3f3a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.municipal-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('municipal-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white relative p-6 rounded-xl bg-opacity-70">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user-request-list', []);

$__html = app('livewire')->mount($__name, $__params, 'KUWwA6j', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07f0778097f2e2be2b5b2161a0d3f3a6)): ?>
<?php $attributes = $__attributesOriginal07f0778097f2e2be2b5b2161a0d3f3a6; ?>
<?php unset($__attributesOriginal07f0778097f2e2be2b5b2161a0d3f3a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07f0778097f2e2be2b5b2161a0d3f3a6)): ?>
<?php $component = $__componentOriginal07f0778097f2e2be2b5b2161a0d3f3a6; ?>
<?php unset($__componentOriginal07f0778097f2e2be2b5b2161a0d3f3a6); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/municipal/index.blade.php ENDPATH**/ ?>