

<!--[if BLOCK]><![endif]--><?php switch($getRecord()->status):
    case ('pending'): ?>
        <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f4792426b7364bb3dac7370e7314380 = $attributes; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Pending','flat' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['warning' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $attributes = $__attributesOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__attributesOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
    <?php break; ?>

    <?php case ('accepted'): ?>
        <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f4792426b7364bb3dac7370e7314380 = $attributes; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Accepted','flat' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $attributes = $__attributesOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__attributesOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
    <?php break; ?>

    <?php case ('declined'): ?>
        <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f4792426b7364bb3dac7370e7314380 = $attributes; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Declined','flat' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['negative' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $attributes = $__attributesOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__attributesOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
    <?php break; ?>

    <?php default: ?>
<?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/filament/tables/status.blade.php ENDPATH**/ ?>