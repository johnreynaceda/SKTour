<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex ">

        <div class="relative top-0 bottom-0 right-0 flex-shrink-0 hidden w-1/3 overflow-hidden bg-cover lg:block">

            <div class="absolute inset-0 z-20 w-full h-full opacity-70 bg-gradient-to-t from-black"></div>
            <img src="<?php echo e(asset('images/bansada.jpg')); ?>" class="z-10 object-cover w-full h-full" />
        </div>
        <div class="relative flex flex-wrap items-center w-full h-full p-8 py-20">
            <div class="relative w-full max-w-md mx-auto lg:mb-0">
                <div class="relative text-center">

                    <div class="flex flex-col mb-6 space-y-2">
                        <div class="text-center font-black text-3xl text-green-600 font-salsa">
                            SKTOUR
                        </div>
                        <h1 class="text-2xl font-semibold tracking-tight">Create an account</h1>
                        <p class="text-sm text-neutral-500">Please enter the required fields.</p>
                    </div>
                    <div>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('auth.register-user', []);

$__html = app('livewire')->mount($__name, $__params, '9w8ZWR2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
                <p class="mt-6 text-sm text-center text-neutral-500">Already have an account? <a
                        href="<?php echo e(route('login')); ?>" class="relative font-medium text-blue-600 group"><span>Login
                            here</span><span
                            class="absolute bottom-0 left-0 w-0 group-hover:w-full ease-out duration-300 h-0.5 bg-blue-600"></span></a>
                </p>
                <p class="px-8 mt-1 text-sm text-center text-neutral-500">By continuing, you agree to our <a
                        class="underline underline-offset-4 hover:text-primary" href="/terms">Terms</a> and <a
                        class="underline underline-offset-4 hover:text-primary" href="/privacy">Policy</a>.</p>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/auth/register.blade.php ENDPATH**/ ?>