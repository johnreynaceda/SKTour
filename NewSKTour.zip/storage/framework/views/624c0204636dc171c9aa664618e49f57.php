<?php if (isset($component)) { $__componentOriginale46c6ece444f379c7637f13bc84097a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale46c6ece444f379c7637f13bc84097a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tourist-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tourist-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <header class="uppercase font-bold text-2xl text-gray-700">Appointments</header>
        <div class="mt-10">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tourist.tourist-appointment', []);

$__html = app('livewire')->mount($__name, $__params, 'UzHUW1h', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale46c6ece444f379c7637f13bc84097a0)): ?>
<?php $attributes = $__attributesOriginale46c6ece444f379c7637f13bc84097a0; ?>
<?php unset($__attributesOriginale46c6ece444f379c7637f13bc84097a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale46c6ece444f379c7637f13bc84097a0)): ?>
<?php $component = $__componentOriginale46c6ece444f379c7637f13bc84097a0; ?>
<?php unset($__componentOriginale46c6ece444f379c7637f13bc84097a0); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/tourist/appointment.blade.php ENDPATH**/ ?>