<div>
    <?php echo e($this->table); ?>

    <?php if (isset($component)) { $__componentOriginal7ea8362733ae9e02c43079506217fb0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ea8362733ae9e02c43079506217fb0f = $attributes; } ?>
<?php $component = WireUi\View\Components\Modal::resolve(['align' => 'center'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'booking_receipt','modal-width' => '3xl']); ?>

        <?php if (isset($component)) { $__componentOriginal526977d3da1dbf047bef54116d3416a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal526977d3da1dbf047bef54116d3416a0 = $attributes; } ?>
<?php $component = WireUi\View\Components\Card::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

            <div class="border-green-600 border-2 p-5">
                <div class="text-center font-bold text-xl text-green-600 font-salsa">
                    BOOKING RECEIPT
                </div>
                <div class="flex justify-between mt-5 items-start">
                    <div>
                        <h1 class="font-bold uppercase text-2xl"><?php echo e($booked_data->tourist_spot->name ?? ''); ?></h1>
                        <h1 class="text-sm"><?php echo e($booked_data->tourist_spot->address ?? ''); ?></h1>
                    </div>
                    <div class="font-bold text-gray-700">
                        <?php echo e(now()->format('F d, Y')); ?>

                    </div>
                </div>
                <div class="mt-10">
                    <span class="text-lg font-medium"> Billing Details:</span>
                    <h1>Booking Fee -
                        &#8369;<?php echo e(number_format($booked_data->tourist_spot->billing_amount ?? 0, 2)); ?>/person x
                        <?php echo e($booked_data->no_of_guest ?? ''); ?></h1>
                    <h1 class="uppercase mt-2 font-bold">Total:
                        <?php echo e(number_format(($booked_data->tourist_spot->billing_amount ?? 0) * ($booked_data->no_of_guest ?? 0), 2)); ?>

                    </h1>


                </div>
                <div class="mt-5">
                    <h1 class="text-lg font-medium">Customer Details:</h1>
                    <div class="flex flex-col space-y-2">
                        <span>Name: <?php echo e(($booked_data->firstname ?? '') . ' ' . ($booked_data->lastname ?? '')); ?></span>
                        <span>Email: <?php echo e($booked_data->email ?? ''); ?></span>
                        <span>Phone Number: <?php echo e($booked_data->phone_number ?? ''); ?></span>
                        <span>Number of Guest: <?php echo e($booked_data->no_of_guest ?? ''); ?></span>
                        <span>Arrival:
                            <?php echo e(\Carbon\Carbon::parse($booked_data->arrival_date ?? '')->format('F d, Y')); ?></span>
                        <span>Address:
                            <?php echo e(($booked_data->address ?? '') . ', ' . ($booked_data->city ?? '') . ', ' . ($booked_data->municipality ?? '')); ?></span>
                    </div>
                </div>
            </div>
             <?php $__env->slot('footer', null, []); ?> 

                <div class="flex justify-end gap-x-4">

                    <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92 = $attributes; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['flat' => true,'label' => 'Close'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['negative' => true,'x-on:click' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $attributes = $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>



                </div>

             <?php $__env->endSlot(); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $attributes = $__attributesOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__attributesOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $component = $__componentOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__componentOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $attributes = $__attributesOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__attributesOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $component = $__componentOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__componentOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\NewSKTour\resources\views/livewire/tourist/tourist-appointment.blade.php ENDPATH**/ ?>